﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OODWebsite.Models
{
    public class LSM
    {
        public int MaNV { get; set; }
        public string TenNV { get; set; }
        public string TenLop { get; set;}
        public string MaHP { get; set; }
        public string TenHP { get; set; }
        public int HocKy { get; set; }
        public int Nam { get; set; }
    }
}