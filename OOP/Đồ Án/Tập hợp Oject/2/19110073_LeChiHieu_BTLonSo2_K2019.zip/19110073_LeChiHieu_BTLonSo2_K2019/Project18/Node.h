#pragma once

#include <string>
using namespace std;
typedef string Data;
class Node
{
public:
	Data Info;
	Node* Next;
}; 
