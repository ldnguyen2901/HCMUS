#include "Shape.h"

const double PI = atan(1) * 4;

